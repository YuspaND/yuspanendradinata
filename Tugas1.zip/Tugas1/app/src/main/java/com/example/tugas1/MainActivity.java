package com.example.tugas1;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etNim=(EditText) findViewById(R.id.nim);
        EditText etPassword=(EditText) findViewById(R.id.password);
        Button btTombol=(Button) findViewById(R.id.btnLogin);
        TextView tvSelamat = (TextView)
                findViewById(R.id.selamatDatang);

        btTombol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nim = etNim.getText().toString();
                tvSelamat.setText("Selamat datang, "+nim);
                String password = etPassword.getText().toString();
                tvSelamat.setText("ur password, "+password);
            }
        });
    }
}